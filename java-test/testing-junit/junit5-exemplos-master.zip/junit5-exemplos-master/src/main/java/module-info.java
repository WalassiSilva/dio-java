module com.github.willyancaetano.junit {
    requires java.logging;
}
