
# Testes unitários com JUnit

Respositório com roteiros e exemplos de como utilizar JUnit no seu dia a dia como dev.  
Foi utilizado para os exemplos a versão 5.8.2, mais atual até o momento (29/01/2022).

## Roteiros

1. [Configurando JUnit](CONFIGURACAO.md)

